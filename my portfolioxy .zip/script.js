let currentUser = null;
let profileId = null;


/* =========================
   ELEMENTS
========================= */

const loginPage =
  document.getElementById("loginPage");

const dashboard =
  document.getElementById("dashboard");

const loginForm =
  document.getElementById("loginForm");

const loginError =
  document.getElementById("loginError");


/* =========================
   AUTH
========================= */

async function checkAuth() {

  const {
    data: {
      session
    }
  } = await supabaseClient.auth.getSession();


  if (session) {

    currentUser =
      session.user;

    showDashboard();

  } else {

    showLogin();

  }

}


function showLogin() {

  loginPage.classList.remove("hidden");

  dashboard.classList.add("hidden");

}


function showDashboard() {

  loginPage.classList.add("hidden");

  dashboard.classList.remove("hidden");

  loadEverything();

}


loginForm.addEventListener(
  "submit",
  async event => {

    event.preventDefault();

    loginError.textContent = "";

    const email =
      document.getElementById("email").value;

    const password =
      document.getElementById("password").value;


    const {
      data,
      error
    } =
      await supabaseClient.auth.signInWithPassword({

        email,
        password

      });


    if (error) {

      loginError.textContent =
        error.message;

      return;

    }


    currentUser = data.user;

    showDashboard();

  }
);


/* Logout */

document
  .getElementById("logoutButton")
  .addEventListener(
    "click",
    async () => {

      await supabaseClient.auth.signOut();

      showLogin();

    }
  );


/* =========================
   NAVIGATION
========================= */

document
  .querySelectorAll(".menu, .quick-card")
  .forEach(button => {

    button.addEventListener(
      "click",
      () => {

        const page =
          button.dataset.page;

        openAdminPage(page);

      }
    );

  });


function openAdminPage(page) {

  document
    .querySelectorAll(".admin-page")
    .forEach(section => {

      section.classList.remove("active");

    });


  const target =
    document.getElementById(
      `${page}Page`
    );


  if (target) {

    target.classList.add("active");

  }


  document
    .querySelectorAll(".menu")
    .forEach(button => {

      button.classList.toggle(
        "active",
        button.dataset.page === page
      );

    });

}


/* View portfolio */

document
  .getElementById("viewSite")
  .addEventListener(
    "click",
    () => {

      window.open(
        "../portfolio/index.html",
        "_blank"
      );

    }
  );


/* =========================
   PROFILE
========================= */

async function loadProfile() {

  const {
    data,
    error
  } = await supabaseClient
    .from("profiles")
    .select("*")
    .limit(1)
    .maybeSingle();


  if (error) {

    console.error(error);

    return;

  }


  if (!data) {

    document
      .getElementById("profileStatus")
      .textContent = "Not set";

    return;

  }


  profileId = data.id;


  document.getElementById(
    "profileName"
  ).value = data.name || "";


  document.getElementById(
    "profileBrand"
  ).value = data.brand || "";


  document.getElementById(
    "profileLocation"
  ).value = data.location || "";


  document.getElementById(
    "profileIdentity"
  ).value = data.identity || "";


  document.getElementById(
    "heroTitle"
  ).value = data.hero_title || "";


  document.getElementById(
    "heroSubtitle"
  ).value = data.hero_subtitle || "";


  document.getElementById(
    "heroDescription"
  ).value = data.hero_description || "";


  document.getElementById(
    "profileImage"
  ).value = data.profile_image_url || "";


  document.getElementById(
    "profileStatus"
  ).textContent = "Ready";

}


document
  .getElementById("profileForm")
  .addEventListener(
    "submit",
    async event => {

      event.preventDefault();


      const payload = {

        name:
          document.getElementById(
            "profileName"
          ).value,

        brand:
          document.getElementById(
            "profileBrand"
          ).value,

        location:
          document.getElementById(
            "profileLocation"
          ).value,

        identity:
          document.getElementById(
            "profileIdentity"
          ).value,

        hero_title:
          document.getElementById(
            "heroTitle"
          ).value,

        hero_subtitle:
          document.getElementById(
            "heroSubtitle"
          ).value,

        hero_description:
          document.getElementById(
            "heroDescription"
          ).value,

        profile_image_url:
          document.getElementById(
            "profileImage"
          ).value,

        updated_at:
          new Date().toISOString()

      };


      let result;


      if (profileId) {

        result =
          await supabaseClient
            .from("profiles")
            .update(payload)
            .eq("id", profileId);

      } else {

        result =
          await supabaseClient
            .from("profiles")
            .insert(payload)
            .select()
            .single();

      }


      if (result.error) {

        showToast(
          result.error.message
        );

        return;

      }


      if (!profileId && result.data) {

        profileId =
          result.data.id;

      }


      document.getElementById(
        "profileMessage"
      ).textContent =
        "Profile saved successfully.";

      showToast("Profile saved");

      loadProfile();

    }
  );


/* =========================
   SOCIAL
========================= */

async function loadSocials() {

  const {
    data,
    error
  } = await supabaseClient
    .from("social_links")
    .select("*")
    .order(
      "display_order",
      {
        ascending: true
      }
    );


  if (error) {

    console.error(error);

    return;

  }


  document.getElementById(
    "socialCount"
  ).textContent =
    data.length;


  const container =
    document.getElementById(
      "socialAdminList"
    );


  container.innerHTML = "";


  data.forEach(item => {

    const card =
      document.createElement(
        "div"
      );

    card.className =
      "admin-item glass";


    card.innerHTML = `

      <div class="item-info">

        <div class="item-icon">
          ${escapeHTML(item.icon || "◎")}
        </div>

        <div>

          <strong>
            ${escapeHTML(item.platform)}
          </strong>

          <small>
            ${escapeHTML(item.username)}
          </small>

        </div>

      </div>

      <div class="item-actions">

        <button
          class="toggle-btn"
          data-id="${item.id}"
        >
          ${item.enabled ? "Enabled" : "Disabled"}
        </button>

        <button
          class="delete-btn"
          data-id="${item.id}"
        >
          Delete
        </button>

      </div>

    `;


    container.appendChild(card);

  });


  container
    .querySelectorAll(".toggle-btn")
    .forEach(button => {

      button.addEventListener(
        "click",
        () => toggleSocial(
          button.dataset.id
        )
      );

    });


  container
    .querySelectorAll(".delete-btn")
    .forEach(button => {

      button.addEventListener(
        "click",
        () => deleteSocial(
          button.dataset.id
        )
      );

    });

}


document
  .getElementById("socialForm")
  .addEventListener(
    "submit",
    async event => {

      event.preventDefault();


      const {
        data: existing
      } =
        await supabaseClient
          .from("social_links")
          .select("display_order")
          .order(
            "display_order",
            {
              ascending: false
            }
          )
          .limit(1);


      const order =
        existing?.length
          ? existing[0].display_order + 1
          : 1;


      const {
        error
      } =
        await supabaseClient
          .from("social_links")
          .insert({

            platform:
              document.getElementById(
                "socialPlatform"
              ).value,

            username:
              document.getElementById(
                "socialUsername"
              ).value,

            url:
              document.getElementById(
                "socialUrl"
              ).value,

            icon:
              document.getElementById(
                "socialIcon"
              ).value || "◎",

            enabled: true,

            display_order: order

          });


      if (error) {

        showToast(
          error.message
        );

        return;

      }


      event.target.reset();

      showToast(
        "Social link added"
      );

      loadSocials();

    }
  );


async function toggleSocial(id) {

  const {
    data,
    error
  } =
    await supabaseClient
      .from("social_links")
      .select("enabled")
      .eq("id", id)
      .single();


  if (error) {

    showToast(error.message);

    return;

  }


  await supabaseClient
    .from("social_links")
    .update({
      enabled: !data.enabled,
      updated_at:
        new Date().toISOString()
    })
    .eq("id", id);


  loadSocials();

}


async function deleteSocial(id) {

  const {
    error
  } =
    await supabaseClient
      .from("social_links")
      .delete()
      .eq("id", id);


  if (error) {

    showToast(error.message);

    return;

  }


  showToast(
    "Social link deleted"
  );

  loadSocials();

}


/* =========================
   PROMOTIONS
========================= */

async function loadPromotions() {

  const {
    data,
    error
  } =
    await supabaseClient
      .from("promotions")
      .select("*")
      .order(
        "created_at",
        {
          ascending: false
        }
      );


  if (error) {

    console.error(error);

    return;

  }


  document.getElementById(
    "promotionCount"
  ).textContent =
    data.length;


  const container =
    document.getElementById(
      "promotionAdminList"
    );


  container.innerHTML = "";


  data.forEach(item => {

    const card =
      document.createElement(
        "div"
      );


    card.className =
      "admin-item glass";


    card.innerHTML = `

      <div class="item-info">

        <img
          class="item-image"
          src="${escapeAttribute(item.image_url)}"
          alt=""
        >

        <div>

          <strong>
            ${escapeHTML(item.title)}
          </strong>

          <small>
            ${escapeHTML(item.description)}
          </small>

        </div>

      </div>

      <div class="item-actions">

        <button
          class="toggle-btn"
          data-id="${item.id}"
        >
          ${item.enabled ? "Enabled" : "Disabled"}
        </button>

        <button
          class="delete-btn"
          data-id="${item.id}"
        >
          Delete
        </button>

      </div>

    `;


    container.appendChild(card);

  });


  container
    .querySelectorAll(".toggle-btn")
    .forEach(button => {

      button.addEventListener(
        "click",
        () => togglePromotion(
          button.dataset.id
        )
      );

    });


  container
    .querySelectorAll(".delete-btn")
    .forEach(button => {

      button.addEventListener(
        "click",
        () => deletePromotion(
          button.dataset.id
        )
      );

    });

}


document
  .getElementById("promotionForm")
  .addEventListener(
    "submit",
    async event => {

      event.preventDefault();


      const {
        error
      } =
        await supabaseClient
          .from("promotions")
          .insert({

            title:
              document.getElementById(
                "promotionTitle"
              ).value,

            description:
              document.getElementById(
                "promotionDescription"
              ).value,

            image_url:
              document.getElementById(
                "promotionImage"
              ).value,

            promotion_url:
              document.getElementById(
                "promotionUrl"
              ).value,

            enabled: true

          });


      if (error) {

        showToast(
          error.message
        );

        return;

      }


      event.target.reset();

      showToast(
        "Promotion added"
      );

      loadPromotions();

    }
  );


async function togglePromotion(id) {

  const {
    data,
    error
  } =
    await supabaseClient
      .from("promotions")
      .select("enabled")
      .eq("id", id)
      .single();


  if (error) {

    showToast(error.message);

    return;

  }


  await supabaseClient
    .from("promotions")
    .update({
      enabled: !data.enabled
    })
    .eq("id", id);


  loadPromotions();

}


async function deletePromotion(id) {

  const {
    error
  } =
    await supabaseClient
      .from("promotions")
      .delete()
      .eq("id", id);


  if (error) {

    showToast(error.message);

    return;

  }


  showToast(
    "Promotion deleted"
  );

  loadPromotions();

}


/* =========================
   SETTINGS
========================= */

async function loadSettings() {

  const {
    data,
    error
  } =
    await supabaseClient
      .from("site_settings")
      .select("*")
      .limit(1)
      .maybeSingle();


  if (error || !data) return;


  document.getElementById(
    "siteName"
  ).value =
    data.site_name || "";


  document.getElementById(
    "footerText"
  ).value =
    data.footer_text || "";

}


document
  .getElementById("settingsForm")
  .addEventListener(
    "submit",
    async event => {

      event.preventDefault();


      const {
        data: existing
      } =
        await supabaseClient
          .from("site_settings")
          .select("id")
          .limit(1)
          .maybeSingle();


      const payload = {

        site_name:
          document.getElementById(
            "siteName"
          ).value,

        footer_text:
          document.getElementById(
            "footerText"
          ).value,

        updated_at:
          new Date().toISOString()

      };


      let result;


      if (existing) {

        result =
          await supabaseClient
            .from("site_settings")
            .update(payload)
            .eq(
              "id",
              existing.id
            );

      } else {

        result =
          await supabaseClient
            .from("site_settings")
            .insert(payload);

      }


      if (result.error) {

        showToast(
          result.error.message
        );

        return;

      }


      document.getElementById(
        "settingsMessage"
      ).textContent =
        "Settings saved.";

      showToast(
        "Settings saved"
      );

    }
  );


/* =========================
   LOAD EVERYTHING
========================= */

async function loadEverything() {

  await loadProfile();

  await loadSocials();

  await loadPromotions();

  await loadSettings();

}


/* =========================
   SECURITY HELPERS
========================= */

function escapeHTML(value) {

  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");

}


function escapeAttribute(value) {

  return escapeHTML(value);

}


/* =========================
   TOAST
========================= */

function showToast(message) {

  const toast =
    document.getElementById(
      "toast"
    );

  toast.textContent =
    message;

  toast.classList.add("show");


  setTimeout(
    () => {
      toast.classList.remove(
        "show"
      );
    },
    2500
  );

}


/* START */

checkAuth();