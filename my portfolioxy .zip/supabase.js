const SUPABASE_URL =
  "https://evcgzexczqpkffbtjjvq.supabase.co";

const SUPABASE_ANON_KEY =
  "sb_publishable_2xiD0s0OlU5dZ_mMavY3ow_s7yEj2mY";

const supabaseClient =
  window.supabase.createClient(
    SUPABASE_URL,
    SUPABASE_ANON_KEY
  );